import '../../domain/entities/adoption_request.dart';

class AdoptionRequestModel extends AdoptionRequest {
  const AdoptionRequestModel({
    required super.id,
    required super.petId,
    required super.adopterId,
    required super.shelterId,
    required super.status,
    required super.message,
  });

  factory AdoptionRequestModel.fromMap(Map<String, dynamic> map) {
    return AdoptionRequestModel(
      id: map['id'] as String,
      petId: map['pet_id'] as String,
      adopterId: map['adopter_id'] as String,
      shelterId: map['shelter_id'] as String,
      status: (map['status'] ?? 'pending') as String,
      message: (map['message'] ?? '') as String,
    );
  }

  Map<String, dynamic> toInsertMap() => {
        'id': id,
        'pet_id': petId,
        'adopter_id': adopterId,
        'shelter_id': shelterId,
        'status': status,
        'message': message,
      };
}
