import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/widgets/app_scaffold.dart';
import '../providers.dart';

class MyRequestsPage extends ConsumerWidget {
  const MyRequestsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reqAsync = ref.watch(myAdoptionRequestsProvider);

    return AppScaffold(
      title: 'Mis solicitudes',
      body: reqAsync.when(
        data: (items) {
          if (items.isEmpty) return const Center(child: Text('Aún no hay solicitudes.'));
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (_, i) {
              final r = items[i];
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.assignment),
                  title: Text('Mascota: ${r.petId}'),
                  subtitle: Text('Estado: ${r.status}\n${r.message}'),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }
}
