import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../../core/utils/env.dart';

class GeminiClient {
  static const String _systemPrompt = 'Eres un asistente experto en bienestar animal. Responde en español, con consejos prácticos y seguros. Si hay síntomas graves, recomienda acudir a un veterinario.';

  final http.Client _http;
  GeminiClient([http.Client? httpClient]) : _http = httpClient ?? http.Client();

  Future<String> generate({
    required List<Map<String, String>> history, // {role:user|model, text:""}
    required String message,
  }) async {
    final key = Env.geminiApiKey;
    if (key.isEmpty) {
      throw Exception('Falta GEMINI_API_KEY en .env');
    }

    final apiVersion = Env.geminiApiVersion; // recomendado: v1
    final model = Env.geminiModel;

    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/$apiVersion/models/$model:generateContent?key=$key',
    );

    // Gemini usa role: user / model
    final contents = <Map<String, dynamic>>[
      // Instrucción inicial (compatibilidad con API v1)
      {'role': 'user', 'parts': [{'text': _systemPrompt}]},
      ...history.map((m) => {
            'role': (m['role'] == 'assistant' || m['role'] == 'model') ? 'model' : 'user',
            'parts': [
              {'text': m['text'] ?? ''}
            ],
          }),
      {
        'role': 'user',
        'parts': [
          {'text': message}
        ],
      }
    ];

    final body = jsonEncode({
      'contents': contents,
      'generationConfig': {
        'temperature': 0.7,
        'maxOutputTokens': 512,
      },
    });

    final res = await _http.post(uri, headers: {'Content-Type': 'application/json'}, body: body);

    if (res.statusCode >= 400) {
      throw Exception('Gemini error ${res.statusCode}: ${res.body}');
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final candidates = (data['candidates'] as List?) ?? [];
    if (candidates.isEmpty) return 'No pude generar respuesta en este momento.';

    final content = candidates.first['content'] as Map<String, dynamic>?;
    final parts = (content?['parts'] as List?) ?? [];
    final text = parts.isNotEmpty ? (parts.first as Map<String, dynamic>)['text'] : null;

    final out = (text ?? '').toString().trim();
    return out.isEmpty ? 'No pude generar respuesta.' : out;
  }
}
